// let lists = [
//   ["Superstructures (ASL)", "COMPANY"],
//   ["400", "COUNTRY"],
//   ["Flat", "AREAS"],
//   ["February", "COUNTRY"],
//   ["Mumbai", "COMPANY"],
//   ["PalaspePanvel", "VALUE"],
//   ["Superstructures", "AREAS"],
//   ["163.25,", "POINTS"],
//   ["9.30", "TIME"],
//   ["6.04 percent", "PERCENT"],
//   ["BSE", "COMPANY"],
// ];

// let key = [];
// let dupKey = [];
// let value = [];

// lists.forEach((list, idx) => {
//   key[idx] = list[1];
//   dupKey[idx] = list[1];
//   value[idx] = list[0];
//   // check(list);
// });

// const check = (e) => {
//   // console.log(e);
//   key.forEach((k, idx) => {
//     if (e === k) {
//       console.log(key[idx]);
//     }
//   });
// };

// let findDuplicates = (arr) =>
//   arr.filter((item, index) => arr.indexOf(item) != index);

// let duplicates = [...new Set(findDuplicates(key))];

// // console.log(duplicates);

// duplicates.forEach((dup) => {
//   check(dup);
// });

// // check(duplicates);

// // console.log(findDuplicates(key)); // All duplicates
